Thanks for playing with A Car Battery!
Adds a single car battery as trash.
Version: 1.0.0
Authors: Hatchery, Kchem


This mod was made with Hatchery 1.0.8
https://github.com/coolbot100s/Hatchery